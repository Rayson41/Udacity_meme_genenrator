This module includes all the data models that are used in the application.

--Models

---QuoteModel
It takes two parameters i.e. `body` and `author` of the quote. The `__repr__`
method is defined for printing the value stored in this model in a human
readable format.