from .quote_model import QuoteModel
